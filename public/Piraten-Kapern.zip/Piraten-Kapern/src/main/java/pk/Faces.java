package pk;

public enum Faces {
    MONKEY, PARROT, GOLD, DIAMOND, SABER, SKULL
}
