package pk;

public enum Cards {
    SEABATTLE300, SEABATTLE500, SEABATTLE1000, NOP, MB
}