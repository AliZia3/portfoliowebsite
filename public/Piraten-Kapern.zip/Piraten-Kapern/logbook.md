Jan 12, 2023

-   Implemented feature to roll 8 dice (F02)

Jan 15, 2023

-   Completed feature F02 (Roll 8 Dice)
-   Implemented feature to Check skulls
-   Implemented feature to score points based on number of gold or diamonds shown (F03)

Jan 16, 2023

-   Completed feature F03 (Player keeping random dice at their turn)
-   Completed feature F04 (Score points: number of gold + diamonds x 100)

Jan 17, 2023

-   Completed Feature F05 (end of turn/no points with three or more skulls)
-   Completed Feature F06 (Turn-based Functionality)
-   Completed MVP
-   Started working on F07 (Track players' scores)
-   Started working on F08 (Play 42 games)
-   Started working on F09 (Print percentage of wins for each player)

Jan 18, 2023

-   Completed F07
-   Completed F08
-   Completed F09
-   Integrated all features for smooth gameplay and simulations

Jan 22, 2023

-   Had to update F02 by shuffling the array because I realized that what I had originally would not be able to fully randomize players rerolling options
-   Updated F01 because I accidentally pushed a wrong feature before

Jan 23, 2023
-   Started working on OOP for all the files
-   Implemented and updated various classes (i.e added a player strategy class, dice data class and a game class and removed checkskull, points scored and turns classes)
-   Completed full OOP code

Jan 25, 2023
-   Worked on the combo points feature and combo player strategy
-   Finished Logger

Jan 26, 2023
-   Worked on and finished the combo points feature and combo player strategy
-   Completed feature to let user decide to use tracer and which strategy to choose from command line argument
-   Started working on Step 5

Jan 27, 2023
-   Created card deck and cards enum
-   Worked on step 5 (Tried figuring out sea battle strategy)

Jan 28, 2023
-   Completed sea battle strategy
-   Started Step 6
-   Implemented monkey business card
-   Implemented strategy to go alongside monkey business card

Jan 29, 2023
-   Fixed log statement and cleaned up code
-   Implemented a new class to keep track of user wanting to use or not use logging statements